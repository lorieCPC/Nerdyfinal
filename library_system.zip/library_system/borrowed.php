<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Reservation_list</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css1/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css1/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css1/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css1/custom.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
   .btn-warning
   {
    margin-top:2px;

   }

   .form-control
   {
    margin-bottom:2%;
   }


</style>


</head>
<body>
  <?php

      require_once("./session.php");

      ?>
  
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" >NERDY<br> <small style="font-size:10px;">Online Library System</small></a>
            </div>

           
        </nav>
        <!-- /. NAV TOP  -->
        <?php 
        require_once("./user.php");
        ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Reservation List</h1>
                        <h1 class="page-subhead-line">Welcome to Nerdy</h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="main-box mb-red" style="background-color:orange;">
                            <a href="./borrowed.php">
                                 <i class="fas fa-book-reader fa-5x"></i>
                                <h5>Reservation List</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-dull" style="background-color:#000080;">
                            <a href="./returnbook.php">
                               <i class="fas fa-exchange-alt fa-5x"></i>
                                <h5>Return</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-pink" style="background-color:black;">
                            <a href="./request.php">
                               <i class="far fa-question-circle fa-5x"></i>
                                <h5>Request</h5>
                            </a>
                        </div>
                    </div>

                </div>
            
                      
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">
                                <form action="./borrowedsearch.php" method="post">
       <div class="input-group" role="group" >                
       <input type="text" id="search" name="search" class="form-control" style="width:50%;border-radius:5px;"/>
     
       <input type="submit" class="btn btn-warning" value="Search" style="width:30%;">
     </div>
</form>
  <br>
                              

   <hr>

                               
                                <!-- Default panel contents -->
      <div class="panel-heading"><b>Book List</b></div>
      <div class="table-wrapper" style="width:100%; height:500px; overflow-x: auto;-webkit-overflow-scrolling: touch;">
      <!-- Table -->
      <table class="table table-hover">
        <thead>
          <tr>
           
             <thead style="background-color:#00008B; color:white; font-size:12px;">
                                        <tr>
                                            <th>Reservation ID</th>
                                            <th>Reservation Date</th>
                                            <th>Book ID</th>
                                            <th>Book Title</th>
                                            <th>Costumer</th>
                                            <th>Book Price</th>
                                            <th>Days</th>
                                            <th>Total Fee</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php
  
   require_once("./connect.php");
  

  $search = $_GET['search'];
   
 $id='';
 $con = new DbConnection();
   if($con->dbStatus() == 1){
    $db = $con->getCon();



if(isset($search))
{
    $sql="SELECT * FROM `book_reservation` WHERE reservation_id LIKE '%{$search}%' OR book_id LIKE '%{$search}%' OR costumer_username LIKE '%{$search}%' OR book_title LIKE '%{$search}%' OR book_price LIKE '%{$search}%' OR date_reservation LIKE '%{$search}%' OR status LIKE '%{$search}%' ";
}
else{
$sql = "SELECT reservation_id,book_id,costumer_username,book_title,book_price,date_reservation,total_fee,days,status FROM `book_reservation` WHERE status='Reserved'";
}

$result=$con->getData($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
   

   ?>
   <tr >
 
    <td><?php echo $row['reservation_id']; ?></td>
    <td><?php echo $row['date_reservation']; ?></td>
    <td><?php echo $row['book_id']; ?></td>
    <td><?php echo $row['book_title']; ?></td>
    <td><?php echo $row['costumer_username']; ?></td>
    <td>&#8369;&nbsp<?php echo $row['book_price']; ?></td>
    <td><?php echo $row['days']; ?></td>
    <td>&#8369;&nbsp<?php echo $row['total_fee']; ?></td>
    <td><button class="btn btn-warning"><i class="fas fa-check-square fa-2x" style="color:blue;" id="borrowed"
      data-reservationid="<?php echo $row['reservation_id'];?>"
      data-reservationdate="<?php echo $row['date_reservation'];?>"
      data-bookid="<?php echo $row['book_id'];?>"
      data-booktitle="<?php echo $row['book_title'];?>"
      data-bookprice="<?php echo $row['book_price'];?>"
      data-days="<?php echo $row['days'];?>"
      data-totalfee="<?php echo $row['total_fee'];?>"
      data-costumeruser="<?php echo $row['costumer_username'];?>"
      ></i></button>


</td>


<?php


}
}

}   


?>


<?php
$con->dbClose();


      ?>
        </tbody>
      </table>
      
  </div>
    </div>
      </div>
</div>




                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    <div class="col-md-4">

                       <?php require_once("./notes.php"); ?>
                </div>
                <!-- /. ROW  -->
              <div class="row">

                    <div class="col-md-12">
                         <div class="jumbotron" style="background-color:blue;color:white;">
                        <h1>Nerdy</h1>
                        <p>"Just in case things get boring, Im bringing a book."</p>
                        <p>
                           <b> -anonymous</b>
                        </p>
                    </div>
</div>
</div>
</div>


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <script>

jQuery(document).ready(function() {
 // executes when HTML-Document is loaded and DOM is ready
console.log("document is ready");
  
  
  jQuery('.btn[href^=#]').click(function(e){
    e.preventDefault();
    var href = jQuery(this).attr('href');
    jQuery(href).modal('toggle');
  });

  

});  





    <div id="footer-sec">
        &copy; 2022 Nerdy | Design By : TeamZ
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    
    <script src="./crudfunct.js"></script>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
   <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

    

    


</body>
</html>