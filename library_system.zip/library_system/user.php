<html>
<head>
	</head>
    <?php
      session_start();
      error_reporting(0);
  

    ?>
	<style>

    p
    {
        margin-top:2px;
        margin-bottom:1px;
    }

   </style>
	<body>
		  
     <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                          <i class="fas fa-user-circle fa-3x" style="color:white;"></i>

                           <?php
                            require_once("./connect.php");
                            $con = new DbConnection();
                            if($con->dbStatus() == 1){
                             $db = $con->getCon();
                             

                             $user=$_SESSION['username'];

                             
                            

                             $sql ="SELECT librarian_id,lname,fname,username FROM `librarian_information` WHERE username='$user'";
                            

                             $result = $con->getData($sql);

                             if ($result->num_rows > 0) {
                            // output data of each row
                            while($row = $result->fetch_assoc()) {
                           $_SESSION['adminid']="ID #: ".$row["librarian_id"];
                           $_SESSION['adminname']=$row["lname"]." ".$row["fname"];
                           $_SESSION['useradmin']=$row["username"];
                          }
                          }
                      }


                         $con->dbClose();

                           ?>

                            

                            <div class="inner-text">
                               <p id="adminname"> </p>
                            <br />
                                <small><p id="adminid">ID : 10052 </p> <p id="adminuser">Jhon15ty</p> </small>
                            </div>
                        </div>
                         
                         <script>

                            document.getElementById('adminname').innerHTML="<?php echo $_SESSION['adminname'];?>";
                            document.getElementById('adminid').innerHTML="<?php echo $_SESSION['adminid'];?>";
                            document.getElementById('adminuser').innerHTML="<?php echo $_SESSION['useradmin'];?>";

                        </script>
                       

                    </li>


                    <li>
                        <a class="active-menu" href="admindashboard.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-book"></i>Books <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="./addbook.php"><i class="fa fa-plus"></i>Add Book</a>
                            </li>
                            <li>
                                <a href="./editbook.php"><i class="fa fa-edit"></i>Edit</a>
                            </li>
                             <li>
                                <a href="./bookhistory.php"><i class="fa fa-search-plus"></i>View History</a>
                            </li>                          
                        </ul>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-exclamation-circle"></i>Action <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                               
                                <a href="./request.php"><i class="fa fa-question-circle"></i>Request <span id="total" style="text-align:right;color:white;padding-left:25px; font-size:15px;color:red;"></span></a>      
                            </li>
                            <li>
                                <a href="./borrowed.php"><i class="fas fa-book-reader"></i>Reservation List</a>
                            </li>
                             <li>
                                <a href="./returnbook.php"> <i class="fas fa-exchange-alt"></i>Return</a>
                            </li>           
                        </ul>
                    </li>
                    <li>
                    	<a href="./logout.php"><i class="fas fa-sign-out-alt"></i>Log out</a>
                    </li>
                </ul>

            </div>

        </nav>
<script>
 var total="<?php echo $_SESSION['total'];?>"
 
 document.getElementById('total').innerHTML=total;
  
</script>


	</body>

	</html>