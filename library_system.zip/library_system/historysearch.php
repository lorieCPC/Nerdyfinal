<?php

 $search = $_POST['search'];

  header("Location:./bookhistory.php?search=".$search);

?>