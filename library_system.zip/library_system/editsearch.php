<?php

 $search = $_POST['search'];

  header("Location:./editbook.php?search=".$search);

?>