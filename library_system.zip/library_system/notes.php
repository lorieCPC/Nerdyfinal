<html>
<title>
	</title>
	<head>

	</head>
	<body>
		<div class="panel panel-primary">
                        <div class="panel panel-default">
                        <div class="panel-heading" style="background-color:blue;color:white;">
                           Information
                        </div>
                        <div class="panel-body" style="font-size:15px;background-color:#F8F8FF;">
                            <h4>Shop Address</h4>
                            <ul>
                                <li>Poblacion Cordova Cebu</li>
                                <li>Cebu Branch</li>
                                <li>
                                    <ul>
                                        <li>Madaue</li>
                                        <li>Canduman</li>
                                        <li>Maguikay</li>
                                    </ul>
                                </li>
                               
                            </ul>
                           <h4>Shop Hours</h4>
                            <ul>
                                <li><b>Mon - Fri :</b> 8 AM to 9 PM</li>
                                <li><b>Sat - Sun :</b> 10 AM to 8 PM</li>
                            
                               
                            </ul>
                            <h4>Contact No. </h4>
                            <ul class="list-inline">
                                <li>Phone: +00 111 222 3333</li>
                                <li>Email: support@nerdy.com</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="panel panel-primary">
                        <div class="panel-heading">
                            Reminder
                        </div>
                        <div class="panel-body" style="background-color:#ADD8E6;">
                            <p>Books give a soul to the universe, wings to the mind, flight to the imagination, and life to everything</p>
                        </div>
                        <div class="panel-footer">
                           Have a nice day!
                        </div>
                    </div>

                                
                     
                          





 </body>
 </html>
