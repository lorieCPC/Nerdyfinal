<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Responsive Bootstrap Advance Admin Template</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css1/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css1/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css1/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css1/custom.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
   .btn-warning
   {
    margin-top:2px;

   }

   .form-control
   {
    margin-bottom:2%;
   }


</style>


</head>
<body>
  <?php

      require_once("./session.php");

      ?>
  
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">NERDY<br> <small style="font-size:10px;">Online Library System</small></a>
            </div>

           
        </nav>
        <!-- /. NAV TOP  -->
        <?php 
        require_once("./user.php");
        ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Book History</h1>
                        <h1 class="page-subhead-line">Welcome to Nerdy!</h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="main-box mb-red" style="background-color:orange;">
                            <a href="./bookhistory.php">
                                <i class="fa fa-search-plus fa-5x"></i>
                                <h5>History</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-dull" style="background-color:#000080;">
                            <a href="./editbook.php">
                               <i class="fa fa-edit fa-5x"></i>
                                <h5>Edit Book</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-pink" style="background-color:black;">
                            <a href="./addbook.php">
                              <i class="fa fa-plus fa-5x"></i>
                                <h5>Add Book</h5>
                            </a>
                        </div>
                    </div>

                </div>
            
                      
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">
                                <form action="./historysearch.php" method="post">
       <div class="input-group" role="group" >                
       <input type="text" id="search" name="search" class="form-control" style="width:50%;border-radius:5px;"/>
     
       <input type="submit" class="btn btn-warning" value="Search" style="width:30%;">
     </div>
</form>
  <br>
                             
                            
  

   <hr>

                               
                                <!-- Default panel contents -->
      <div class="panel-heading">Book List</div>
      <div class="table-wrapper" style="width:100%; height:500px; overflow-x: auto;-webkit-overflow-scrolling: touch;">
      <!-- Table -->
      <table class="table table-hover">
        <thead>
          <tr>
           
             <thead style="background-color:#00008B; color:white; font-size:12px;">
                                        <tr>
                                            <th>Book ID</th>
                                            <th>Book Title</th>
                                            <th>Book Price</th>
                                            <th>Date Borrowed</th>
                                            <th>Costumer</th>
                                            <th>Days</th>
                                            <th>Total Fee</th>
                                            <th>Date Returne</th>
                                            <th>Librarian</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php
  
   require_once("./connect.php");
  

  $search = $_GET['search'];
   
 $id='';
 $con = new DbConnection();
   if($con->dbStatus() == 1){
    $db = $con->getCon();



if(isset($search))
{
    $sql="SELECT * FROM `book_borrowed` WHERE borrowed_id LIKE '%{$search}%' OR book_id LIKE '%{$search}%' OR costumer_username LIKE '%{$search}%' OR librarian_username LIKE '%{$search}%' OR book_id LIKE '%{$search}%' OR book_title LIKE '%{$search}%' OR date_borrowed LIKE '%{$search}%' OR status LIKE '%{$search}%' ";
}
else{
$sql = "SELECT borrowed_id,costumer_username,librarian_username,book_id,book_title,book_price,date_borrowed,date_returne,days,total_fee,status FROM `book_borrowed`";
}

$result=$con->getData($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
   

   ?>
   <tr >
  
    <td><?php echo $row['book_id']; ?></td>
    <td><?php echo $row['book_title']; ?></td>
    <td>&#8369;&nbsp<?php echo $row['book_price']; ?></td>
    <td><?php echo $row['date_borrowed']; ?></td>
    <td><?php echo $row['costumer_username']; ?></td>
    <td><?php echo $row['days']; ?></td>
    <td>&#8369;&nbsp<?php echo $row['total_fee']; ?></td>
    <td><?php echo $row['date_returne']; ?></td>
    <td><?php echo $row['librarian_username']; ?></td>

<?php 
    if($row['status']==="Return")
    { ?>
    <td style="color:green;"><?php echo $row['status']; ?></td>

    <?php
}
       else if ($row['status']==="Unreturn")
       { 

        ?>
         <td style="color:red;"><?php echo $row['status']; ?></td>



         <?php

     } 

      
       ?>

</td>


<?php

}
}

}   


?>


<?php
$con->dbClose();


      ?>
        </tbody>
      </table>
      
  </div>
    </div>
      </div>
</div>




                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    <div class="col-md-4">

                        <?php 
                         require_once("./notes.php"); ?>
                </div>
                <!-- /. ROW  -->
              <div class="row">

                    <div class="col-md-12">
                          <div class="jumbotron" style="background-color:blue;color:white;">
                        <h1>Nerdy</h1>
                        <p>"Just in case things get boring, Im bringing a book."</p>
                        <p>
                           <b> -anonymous</b>
                        </p>
                    </div>
</div>
</div>
</div>


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

  





    <div id="footer-sec">
        &copy; 2022 Nerdy | Design By : TeamZ
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    
    <script src="./crudfunct.js"></script>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
   <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

    

    


</body>
</html>
