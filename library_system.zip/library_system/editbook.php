<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>EditBook</title>

    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css1/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css1/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css1/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css1/custom.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>
   .btn-warning
   {
    margin-top:2px;

   }

   .form-control
   {
    margin-bottom:2%;
   }

   label
   {
    margin-bottom:2px;
   }

</style>
</head>
<body>
  <?php

      require_once("./session.php");

      ?>
  
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">NERDY<br> <small style="font-size:10px;">Online Library System</small></a>
            </div>

           
        </nav>
        <!-- /. NAV TOP  -->
        <?php 
        require_once("./user.php");
        ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Edit Book</h1>
                        <h1 class="page-subhead-line">Welcome to Nerdy!</h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="main-box mb-red" style="background-color:orange;">
                            <a href="./addbook.php">
                                <i class="fa fa-plus fa-5x"></i>
                                <h5>Add Book</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-dull" style="background-color:#000080;">
                            <a href="./editbook.php">
                               <i class="fa fa-edit fa-5x"></i>
                                <h5>Edit Book</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-pink" style="background-color:black;">
                            <a href="./bookhistory.php">
                              <i class="fa fa-search-plus fa-5x"></i>
                                <h5>History</h5>
                            </a>
                        </div>
                    </div>

                </div>
            
                      
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-12">
                                <form action="./editsearch.php" method="post">
       <div class="input-group" role="group" >                
       <input type="text" id="search" name="search" class="form-control" style="width:50%;border-radius:5px;"/>
     
       <input type="submit" class="btn btn-warning" value="Search" style="width:30%;">
     </div>
</form>
  <br>
                             
                            
  

   <hr>

                               
                                <!-- Default panel contents -->
      <div class="panel-heading">Book List</div>
      <div class="table-wrapper" style="width:100%; height:500px; overflow-x: auto;-webkit-overflow-scrolling: touch;">
      <!-- Table -->
      <table class="table table-hover">
        <thead>
          <tr>
           
             <thead style="background-color:#00008B; color:white;">
                                        <tr>
                                            <th>ID</th>
                                            <th>Title</th>
                                            <th>Publisher</th>
                                            <th>Writer</th>
                                            <th>Department </th>
                                            <th>Price</th>
                                            <th>Rack</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php
  
   require_once("./connect.php");
  

  $search = $_GET['search'];
   
 $id='';
 $con = new DbConnection();
   if($con->dbStatus() == 1){
    $db = $con->getCon();



if(isset($search))
{
    $sql="SELECT * FROM `book_information` WHERE book_title LIKE '%{$search}%' OR book_publisher LIKE '%{$search}%' OR book_writer LIKE '%{$search}%' OR book_department LIKE '%{$search}%' OR book_status LIKE '%{$search}%'";
}
else{
$sql = "SELECT book_id,book_title,book_publisher,book_writer,book_price,rack,book_department,book_status FROM book_information";
}

$result=$con->getData($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
   

   ?>
   <tr >
    <td><?php echo $row['book_id']; $id=$row['book_id'];?></td>

   

    <td><?php echo $row['book_title']; ?></td>
    <td><?php echo $row['book_publisher']; ?></td>
    <td><?php echo $row['book_writer']; ?></td>
    <td><?php echo $row['book_department']; ?></td>
    <td><?php echo $row['book_price']; ?></td>
    <td><?php echo $row['rack']; ?></td>

<?php 
    if($row['book_status']==="Free")
    { ?>
    <td style="color:green;"><?php echo $row['book_status']; ?></td>

    <?php
}
       else if ($row['book_status']==="Not Free")
       { 

        ?>
         <td style="color:red;"><?php echo $row['book_status']; ?></td>


         <?php

        }

        else 
        {

        ?>
         <td style="color:orange;"><?php echo $row['book_status']; ?></td>

         <?php

     } 

      
       ?>

<td><a href="#Edit"  class="btn btn-warning"><i class="fas fa-pen-square fa-1x"  id="edit" data-toggle="tooltip"
                    data-id1="<?php echo $row["book_id"]; ?>"
                    data-title="<?php echo $row["book_title"]; ?>"
                    data-publisher="<?php echo $row["book_publisher"]; ?>"
                    data-writer="<?php echo $row["book_writer"]; ?>"
                    data-department="<?php echo $row["book_department"]; ?>"
                    data-price="<?php echo $row["book_price"]; ?>"
                    data-rack="<?php echo $row["rack"]; ?>"
                    data-status="<?php echo $row["book_status"];?>"
                    title="Edit">

</i></a>
<?php 
   if($row['book_status']==="Pending" || $row['book_status']==="Not Free" || $row['book_status']==="Reserved")
   {?>

<a href='#Delete' id="delete1"  class='btn btn-warning' style="display:none;"><i class='fas fa-trash'id="delet" data-id2="<?php echo $row["book_id"]; ?>" title="delete"></i></a></td>


<?php

} else {

?>

<a href='#Delete'  class='btn btn-warning' ><i class='fas fa-trash'id="delet" data-id2="<?php echo $row["book_id"]; ?>" title="delete"></i></a></td>

<?php
}
?>




<?php

}
}

}   


?>


<?php
$con->dbClose();


      ?>
        </tbody>
      </table>
      
  </div>
    </div>
      </div>
</div>



<!--Modal-->


<div class="modal" id="Edit" tabindex="-1" role="dialog" >
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b>Please Fill Up</b></h5>
        
      </div>
      <div class="modal-body">
       
       <form onsubmit="event.preventDefault(); Update(event);" enctype="multipart/form-data">

          <input type="hidden" name="id" id="id" class="form-control">
          <label style="width:100%;"></>Book Title:
          <input type="text" name="title" id="title" placeholder="Book Title " class="form-control" required><label>
             <label  style="width:100%;"></>Book Publisher:
          <input type="text" name="publisher" id="publisher" placeholder="Publisher" class="form-control" required></label>
           <label style="width:100%;"></>Book Writer:
          <input type="text" name="writer" id="writer" placeholder="Writer " class="form-control" required></label>
            <label style="width:100%;"></>Book Department:
          <input list="departments" type="text" name="department" id="department" placeholder="Department " class="form-control"
          onkeydown="return true;" required></label>
           <datalist id="departments">
            <option value="Technology">
            <option value="Science">
             <option value="Math">
           <option value="Cookings">
          <option value="Business">
        <option value="Accountancy">
          <option value="Novels">
        <option value="Education">
          <option value="Comics">
          </datalist>
            <label style="width:100%;"></>Book Price:
          <input type="number" name="price" id="price" placeholder="Book Price" class="form-control" required></label>
            <label style="width:100%;"></>Book Rack:
          <input type="number" name="rack" id="rack" placeholder="Rack #" class="form-control" required></label>
            <label style="width:100%;"></>Book Status:
          <input list="stats" type="text"  name="status" id="status" placeholder="Status " class="form-control" onkeydown="return true;" required></label>
           <datalist id="stats">
            <option value="Free">
            <option value="Not Free">
             <option value="Reserved">
          </datalist>

          
      </div>
      <div class="modal-footer">
        <input  type="submit"  id="updating" class="btn btn-primary" value="Save">
         </form>
        <button type="button" id="cancel" class="btn btn-warning" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>


<div class="modal" id="Delete" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
          <h5 class="modal-title"><b>Delete</b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form onsubmit="event.preventDefault(); Delete(event);" enctype="multipart/form-data">
        <input type="hidden" id="id_d" name="id_d" class="form-control">                   
        <p>Are you sure you want to delete this information?</p>              
      </div>
      <div class="modal-footer">
        <input type="submit" id="delete2" class="btn btn-warning" value="Delete">
      </form>
        <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>








                    <!-- /.REVIEWS &  SLIDESHOW  -->
                    <div class="col-md-4">

                        <?php require_once("./notes.php");?>
                </div>
                <!-- /. ROW  -->
              <div class="row">

                    <div class="col-md-12">
                         <div class="jumbotron" style="background-color:blue;color:white;">
                        <h1>Nerdy</h1>
                        <p>"Just in case things get boring, Im bringing a book."</p>
                        <p>
                           <b> -anonymous</b>
                        </p>
                    </div>
</div>
</div>
</div>


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <script>

jQuery(document).ready(function() {
 // executes when HTML-Document is loaded and DOM is ready
console.log("document is ready");
  
  
  jQuery('.btn[href^=#]').click(function(e){
    e.preventDefault();
    var href = jQuery(this).attr('href');
    jQuery(href).modal('toggle');
  });

  

});  
    </script>



    <div id="footer-sec">
        &copy; 2022 Nerdy | Design By : TeamZ
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    
    <script src="./crudfunct.js"></script>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
   <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>

    

    


</body>
</html>
