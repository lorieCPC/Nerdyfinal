<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Responsive Bootstrap Advance Admin Template</title>

    
    <link href="assets/css1/bootstrap.css" rel="stylesheet" /> 
       
    <link href="assets/css1/basic.css" rel="stylesheet" />
    
    <link href="assets/css1/custom.css" rel="stylesheet" />

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- google font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
   
</head>
<body>
    <?php

        require_once("./session.php");

        ?>
   
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">NERDY<br> <small style="font-size:10px;">Online Library System</small></a>
            </div>

           
        </nav>
        <?php
         require_once("./user.php");

         ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add Book</h1>
                        <h1 class="page-subhead-line">Welcome to Nerdy!</h1>

                    </div>
                </div>
                <!-- /. ROW  -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="main-box mb-red" style="background-color:orange;">
                            <a href="./editbook.php">
                                <i class="fa fa-edit fa-5x"></i>
                                <h5>Edit Book</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-dull" style="background-color:#000080;">
                            <a href="./editbook.php">
                               <i class="fa fa-plus fa-5x"></i>
                                <h5>Add Book</h5>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="main-box mb-pink" style="background-color:black;">
                            <a href="./bookhistory.php">
                              <i class="fa fa-search-plus fa-5x"></i>
                                <h5>History</h5>
                            </a>
                        </div>
                    </div>

                </div>
            
                      
                <div class="row">
                    <div class="col-md-12">
                        
                             
                               
                               <div class="panel panel-info" style="width:50%; margin-left:25%; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">
                        <div class="panel-heading" style="background-color:#00008B;color:white;">
                           Book Information
                        </div>
                        <div class="panel-body" style="background-color:#F8F8FF;" >
                            <form onsubmit="event.preventDefault(); AddBook(event);" enctype="multipart/form-data">
                                        
                                        <div class="form-group">
                                            <label>Book Title</label>
                                            <input class="form-control"  name="title" id="title" type="text" required >
                                        </div>
                                 <div class="form-group">
                                            <label>Book Publisher</label>
                                            <input class="form-control" name="publisher" id="publisher" type="text" required>
                                    
                                        </div>
                                <div class="form-group">
                                            <label>Writer</label>
                                            <input class="form-control" name="writer" id="writer" type="text" required>
                                    
                                        </div>
                                <div class="form-group">
                                            <label>Book Department</label>
                                            <input list="departments" class="form-control" name="department" id="department" type="text" onkeydown="return false;" required>
                                            <datalist id="departments">
                                                <option value="Technology">
                                                <option value="Science">
                                                <option value="Math">
                                                <option value="Cookings">
                                                <option value="Business">
                                                <option value="Accountancy">
                                                <option value="Novels">
                                                <option value="Education">
                                                <option value="Comics">
                                                </datalist>

                                    
                                        </div>
                                 <div class="form-group">
                                            <label>Book Price </label>
                                            <input class="form-control" name="price" id="price"  type="number" required>
                                    
                                        </div>

                                <div class="form-group">
                                            <label>Rack No. </label>
                                            <input class="form-control" name="rack" id="rack"  type="number" required>
                                    
                                        </div>

                                       
                                 
                                        <button type="submit" class="btn btn-warning" style="width:50%; border-radius:25px; background-color:orange;">Add </button>

                                    </form>
                           
    </div>
</div>
</div>

                </div>
                <!-- /. ROW  -->

                         <div class="jumbotron" style="background-color:blue;color:white;">
                        <h1>Nerdy</h1>
                        <p>"Just in case things get boring, Im bringing a book."</p>
                        <p>
                           <b> -anonymous</b>
                        </p>
                    </div>

 

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2022 Nerdy | Design By : TeamZ
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="./crudfunct.js"></script>
    <!-- jquery -->
    <script src="assets/js/jquery-1.11.3.min.js"></script>
    <!-- bootstrap -->
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <!-- count down -->
    <script src="assets/js/jquery.countdown.js"></script>
    <!-- isotope -->
    <script src="assets/js/jquery.isotope-3.0.6.min.js"></script>
    <!-- waypoints -->
    <script src="assets/js/waypoints.js"></script>
    <!-- owl carousel -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- magnific popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- mean menu -->
    <script src="assets/js/jquery.meanmenu.min.js"></script>
    <!-- sticker js -->
    <script src="assets/js/sticker.js"></script>
    <!-- main js -->
    <script src="assets/js/main.js"></script>

    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    


</body>
</html>
