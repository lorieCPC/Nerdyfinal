<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	

	<!-- title -->
	<title>Books</title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="assets/img/favicon.png">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="assets/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="assets/css/responsive.css">

	<style>
      .form-control
      {
      	margin-top:2%;

      }

      tr:hover
      {
      	background-color:#D3D3D3;
      }

      label
      {
      	margin-left:15%;
      }

     input
      {
      	margin-left:15%;
      }



	</style>

</head>
<body>
	<?php
     require_once("./session.php");

	?>
	
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="./index_2.html">
								<img src="img/logo.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
								<li active>
								<a  href="index_2.php">Home</a>		
								</li>
								<li><a href="about.php">About</a></li>
								<li><a href="profile.php">Profile</a>
								</li>
								<li><a href="shop.php"><div class="act">Books</div></a></li>
								<li><a href="./logout.php">Log Out</a></li>
								<li>
									<div class="header-icons">
										<?php
										  require_once("./notification.php");
										  ?>
                                        <a class="mobile-hide search-bar-icon" href="#"><i class="fas fa-search"></i></a>
									</div>
								</li>
							</ul>
						</nav>

						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->

	<!-- search area -->
	<div class="search-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<span class="close-btn"><i class="fas fa-window-close"></i></span>
					<div class="search-bar">
						<div class="search-bar-tablecell">
							<h3>Search For:</h3>
							<form method="post" action="./searchbook.php">
							<input type="text" id="search" name="search" placeholder="Books">
							<button type="submit">Search <i class="fas fa-search"></i></button>
						</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end search arewa -->

	
	<!-- breadcrumb-section -->
	<div class="breadcrumb-section breadcrumb-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="breadcrumb-text">
						<p>Explore and Enjoy</p>
						<h1>Books</h1>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end breadcrumb section -->

	<div class="table-wrapper" style="width:100%; height:500px; overflow-x: auto;-webkit-overflow-scrolling: touch;">

		<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Publisher</th>
      <th scope="col">Writer</th>
      <th scope="col">Department</th>
      <th scope="col">Price</th>
      <th scope="col">Rack No.</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>

 <?php
   error_reporting(0);
   require_once("./connect.php");

  $search = $_GET['search'];
   

 $con = new DbConnection();
   if($con->dbStatus() == 1){
    $db = $con->getCon();



if(isset($search))
{
    $sql="SELECT * FROM `book_information` WHERE book_title LIKE '%{$search}%' OR book_publisher LIKE '%{$search}%' OR book_writer LIKE '%{$search}%' OR book_department LIKE '%{$search}%' OR book_status LIKE '%{$search}%' OR rack LIKE '%{$search}%' OR book_price LIKE '%{$search}%'";
}
else{
$sql = "SELECT book_id,book_title,book_publisher,book_writer,rack,book_department,book_status,book_price FROM book_information";
}

$result=$con->getData($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
   ?>
   <tr>
    <td ><?php echo $row['book_title']; ?></td>
    <td><?php echo $row['book_publisher']; ?></td>
    <td><?php echo $row['book_writer']; ?></td>
    <td><?php echo $row['book_department']; ?></td>
    <td>&#8369; <?php echo $row['book_price'];?> per day</td>
    <td><?php echo $row['rack']; ?></td>

<?php 
    if($row['book_status']==="Free")
    { ?>
    <td style="color:green;"><?php echo $row['book_status']; ?></td>

    <?php
}
       else if ($row['book_status']==="Not Free")
       { 

        ?>
         <td style="color:red;"><?php echo $row['book_status']; ?></td>


         <?php

        }

        else 
        {

        ?>
         <td style="color:orange;"><?php echo $row['book_status']; ?></td>

         <?php

     }

       if($row['book_status']==="Not Free" || $row['book_status']==="Reserved" || $row['book_status']==="Pending")
       {

     ?>

     
    <td><button id='reserve' class='btn btn-warning' data-toggle='modal' data-target='#myModal' disabled> Reserve</button></td>

    </tr> 
<?php
}

else  {

?>
<td><button id='reserve' class='btn btn-warning' data-toggle='modal' data-target='#myModal'  data-id="<?php echo $row["book_id"]; ?>"  data-title="<?php echo $row["book_title"]; ?>"  data-price="<?php echo $row["book_price"]; ?>"> Reserve</button></td>

<?php
}
}
}

}   


?>


<?php
$con->dbClose();


      ?>

</tbody>
</table>


</div>

<div class="modal" id="myModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Please Fill Up</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p><b>Book Reservation</b></p>
        <form onsubmit="event.preventDefault(); Reserve(event);" enctype="multipart/form-data">
        	<input type="hidden" name="bookid" id="bookid">
            <label for="username">Username: 
        	<input type="text" name="username" id="username" onkeydown="return false;" value="<?php echo $_SESSION['username'];?>" class="form-control"></label><br>
        	<label for="title">Book Title:
        	<input type="text" name="title" id="title"  class="form-control" onkeydown="return false;">
            </label>
            <label for="price">Price per day:
        	<input type="text" name="price" id="price"  class="form-control" onkeydown="return false;">
           </label>
           <label for="reservedate">Reservation date:
           	<input id="datefield" type="date" name="date" id="date" class="form-control">
           </label>
           <label for="days">Days:<br>
            <input type="number" name="days" id="days" min="1" max="30" class="form-control" style="margin-left:2px;">
        </label>


     
      </div>
      <div class="modal-footer">
        <input type="submit" class="btn btn-primary" value="Submit">
           </form>
      </div>
    </div>
  </div>
</div>




	
	
	<!-- copyright -->
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyrights &copy; 2019 - TeamZ,  All Rights Reserved.</p>
				</div>
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-linkedin"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-dribbble"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
<script>
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();

if (dd < 10) {
   dd = '0' + dd;
}

if (mm < 10) {
   mm = '0' + mm;
} 
    
today = yyyy + '-' + mm + '-' + dd;
document.getElementById("datefield").setAttribute("min", today);



</script>
	

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

	<!-- end copyright -->
	<script src="./crudfunct.js"></script>
	<!-- jquery -->
	<script src="assets/js/jquery-1.11.3.min.js"></script>
	<!-- bootstrap -->
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- count down -->
	<script src="assets/js/jquery.countdown.js"></script>
	<!-- isotope -->
	<script src="assets/js/jquery.isotope-3.0.6.min.js"></script>
	<!-- waypoints -->
	<script src="assets/js/waypoints.js"></script>
	<!-- owl carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- magnific popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<!-- mean menu -->
	<script src="assets/js/jquery.meanmenu.min.js"></script>
	<!-- sticker js -->
	<script src="assets/js/sticker.js"></script>
	<!-- main js -->
	<script src="assets/js/main.js"></script>

</body>
</html>