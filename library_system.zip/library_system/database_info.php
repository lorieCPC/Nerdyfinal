<?php

   define("SERVER",'localhost');
    define("username","root");
    define("password",'');
    define("database","library_information");
	
?>