<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	

	<!-- title -->
	<title>Profile</title>

	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="img/favicon.png">
  <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="assets/css/all.min.css">
	<!-- bootstrap -->
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<!-- owl carousel -->
	<link rel="stylesheet" href="assets/css/owl.carousel.css">
	<!-- magnific popup -->
	<link rel="stylesheet" href="assest/css/magnific-popup.css">
	<!-- animate css -->
	<link rel="stylesheet" href="assets/css/animate.css">
	<!-- mean menu css -->
	<link rel="stylesheet" href="assets/css/meanmenu.min.css">
	<!-- main style -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- responsive -->
	<link rel="stylesheet" href="assets/css/responsive.css">
<style>
.form-control{
	width:100%;
	margin-bottom:2px;
}
label
{
	font-size:13px;
}

.table-wrapper
{
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
	margin-bottom:25px;
}

.btn-outline-primary{
  padding-top:15px;
  padding-bottom:15px;
}

.btn-outline-warning{
  padding-top:15px;
  padding-bottom:15px;
}

.btn:hover
{
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

</style>


</head>
<body>

	
	
	<?php
	   require_once('./session.php');

	   ?>
	
	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.html">
								<img src="img/logo.png" alt="Logo">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
								<li>
								<a href="./index_2.php">Home</a>		
								</li>
								<li ><a href="./about.php">About</a></li>
								<li><a href="./profile.php"><div class="act">Profile</div></a>
								</li>
								<li><a href="./shop.php">Books</a></li>
								<li><a href="./logout.php">Log Out</a>
								</li>
								<li>
									<div class="header-icons">
									<?php
                    require_once("./notification.php");

                    ?>
										
									</div>
								</li>
							</ul>
						</nav>

						<div class="mobile-menu"></div>
						
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->
	
	<!-- breadcrumb-section -->
	<div class="breadcrumb-section breadcrumb-bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 offset-lg-2 text-center">
					<div class="breadcrumb-text">
						<i class="fas fa-user-circle fa-7x" style="color:orange"></i>

						<p id="user" style="padding-top:35px; color:white;font-size:15px"></p>
					</div>
				</div>
			</div>
		</div>
	</div>

	                       <script>
							var user ="<?php echo $_SESSION['username']; ?>";
							 document.getElementById('user').innerHTML =user;

						</script>
	<!-- end breadcrumb section -->

	<div class="container">
			<div class="row">
                <div class="col-md-12">
                    <div class="product-filters" style="padding-top:30px; padding-left:35%;">

                        <button class="btn btn-outline-primary" id="btnreserve" style="width:20%;border-radius:15px;">Reserve</button>
                         <button class="btn btn-outline-warning" id="btnborrow" style="width:20%; border-radius:15px;">Borrowed</button>
                    </div>
                </div>
            </div>

	<div class="table-wrapper" id="reserve" style="width:100%; height:500px; overflow-x: auto;-webkit-overflow-scrolling: touch;">

		<table class="table"  >
  <thead class="thead-dark">
    <tr>
      <th scope="col">Reservation Date</th>
      <th scope="col">Book Title</th>
      <th scope="col">Book Price</th>
      <th scope="col">Days</th>
      <th scope="col">Total Fee</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  	<?php
      require_once("./connect.php");
      $username=$_SESSION['username'];
       
    
      $con = new DbConnection();
      if($con->dbStatus() == 1){
      $db = $con->getCon();

      $sql = "SELECT reservation_id,book_id,costumer_username,book_title,book_price,date_reservation,total_fee,days,status FROM `book_reservation` WHERE costumer_username='$username'";
      $result=$con->getData($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {

  	?>
    <tr>
  	 <td><?php echo $row['date_reservation'];?></td>
  	 <td><?php echo $row['book_title'];?></td>
  	 <td>&#8369;&nbsp<?php echo $row['book_price'];?></td>
  	 <td><?php echo $row['days'];?></td>
  	 <td>&#8369;&nbsp<?php echo $row['total_fee'];?></td>
  	 <?php if($row['status']==="Pending"){?>
  	 <td style="color:orange;"><?php echo $row['status'];?></td>
  	<?php }
  	 else 
  	 	{?>
  	 <td style="color:green;">Accept</td>
  	 <?php
      } ?>
  	 

  	  <td><button class="btn btn-primary" data-toggle="modal" data-target="#EditReserve"><i class="fas fa-edit" id="icon_reserve"
  	  	 data-reserveid="<?php echo $row["reservation_id"];?>"
  	  	 data-booktitle="<?php echo $row["book_title"];?>"
  	  	 data-bookprice="<?php echo $row["book_price"];?>"
  	  	 data-costumeruser="<?php echo $row["costumer_username"];?>"
  	  	 >
  	  	</i></button>	
  	  	  <button class="btn btn-warning" data-toggle="modal" data-target="#Cancel"><i class="fas fa-window-close" id="icon_cancel"
  	  	  	 	  	 data-idreserve="<?php echo $row["reservation_id"];?>"
  	  	  	 	  	 data-costumer="<?php echo $row["costumer_username"];?>"
  	  	  	 	  	 data-bookid="<?php echo $row["book_id"];?>"
  	  	  	 	  	 ></i></button>

  	  	</td>
   </tr>
 

  	 <?php

}
}

}   


?>


<?php
$con->dbClose();


      ?>
  </tbody>
</table>
</div>

<div class="table-wrapper" id="borrow" style="width:100%; height:500px; overflow-x: auto;-webkit-overflow-scrolling: touch;display:none;">
<table class="table"  >
  <thead class="thead-dark">
    <tr>
      <th scope="col">Borrowed Date</th>
      <th scope="col">Book Title</th>
      <th scope="col">Book Price</th>
      <th scope="col">Days</th>
      <th scope="col">Total Fee</th>
      <th scope="col">Date Return</th>
      <th scope="col">Librarian</th>
      <th scope="col">Status</th>

    </tr>
  </thead>
  <tbody>
  	<tr>
  	<?php
      require_once("./connect.php");
      $username=$_SESSION['username'];

      $con = new DbConnection();
      if($con->dbStatus() == 1){
      $db = $con->getCon();

      $sql = "SELECT date_borrowed,book_id,book_title,book_price,days,total_fee,borrowed_id,status,date_returne,librarian_username FROM `book_borrowed` WHERE costumer_username='$username'";
      $result=$con->getData($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
  	?>
  
   <td><?php echo $row['date_borrowed'];?></td>
   <td><?php echo $row['book_title'];?></td>
   <td>&#8369;&nbsp<?php echo $row['book_price'];?></td>
   <td><?php echo $row['days'];?></td>
   <td>&#8369;&nbsp<?php echo $row['total_fee'];?></td>
   <td><?php echo $row['date_returne'];?></td>
   <td><?php echo $row['librarian_username'];?></td>

   <?php if($row['status']==="Unreturn"){?>
    <td style="color:red;"><?php echo $row['status'];?></td>
   </tr>
    <?php 
  } else{?>
     <td style="color:green;"><?php echo $row['status'];?></td>
</tr>

   <?php
 }
}
}
}
$con->dbClose();
?>

  </tbody>
</table>
</div>



</div>

</div>

<div class="modal" id="EditReserve" tabindex="-1" role="dialog" >
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:blue;">
        <h5 class="modal-title" style="color:white;"><b>Please Fill Up</b></h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span></button>
        
      </div>
      <div class="modal-body">
       
       <form onsubmit="event.preventDefault(); UpdateReservation(event);" enctype="multipart/form-data">
       	  <input type="hidden" name="costumer_name" id="costumer_name" class="form-control">
          <input type="hidden" name="reservation_id" id="reservation_id" class="form-control">
          <label for="title">Book Title
          <input type="text" name="book_title" id="book_title" placeholder="Book Title " class="form-control"  onkeydown="return false;">
      </label>
           <label for="price">Book Price
          <input type="text" name="book_price" id="book_price" placeholder="Book Price" class="form-control"  onkeydown="return false;">
      </label>
          <label for="Reservation" style="width:50%;">Reservation Date
          <input type="date" id="datefield" name="reserve" id="reserve" class="form-control" required >
           </label>
           
           <label for="days">Days
          <input type="number" name="days" id="days" min="1" max="30" class="form-control" required>
      </label>
         
      </div>
      <div class="modal-footer">
        <input  type="submit"  id="updatereserve" class="btn btn-primary" value="Save">
         </form>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="Cancel" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:orange;">
          <h5 class="modal-title"><b>Cancel Reservation</b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <form onsubmit="event.preventDefault(); CancelReservation(event);" enctype="multipart/form-data">
        <input type="hidden" id="id_reservation" name="id_reservation" class="form-control"> 
          <input type="hidden" id="costumer" name="costumer" class="form-control">  
           <input type="hidden" id="book_id" name="book_id" class="form-control">        
        <p>Are you sure you want to cancel this reservation?</p>              
      </div>
      <div class="modal-footer">
        <input type="submit"  class="btn btn-warning" value="Yes">
      </form>
      </div>
    </div>
  </div>
</div>
	
	

	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyrights &copy; 2022 - TeamZ,  All Rights Reserved.</p>
				</div>
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-linkedin"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-dribbble"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>


  <script>
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();

if (dd < 10) {
   dd = '0' + dd;
}

if (mm < 10) {
   mm = '0' + mm;
} 
    
today = yyyy + '-' + mm + '-' + dd;
document.getElementById("datefield").setAttribute("min", today);



</script>
	<!-- end copyright -->

	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


  <script src="./crudfunct.js"></script>
	
	<!-- jquery -->
	<script src="assets/js/jquery-1.11.3.min.js"></script>
	<!-- bootstrap -->
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<!-- count down -->
	<script src="assets/js/jquery.countdown.js"></script>
	<!-- isotope -->
	<script src="assets/js/jquery.isotope-3.0.6.min.js"></script>
	<!-- waypoints -->
	<script src="assets/js/waypoints.js"></script>
	<!-- owl carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- magnific popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<!-- mean menu -->
	<script src="assets/js/jquery.meanmenu.min.js"></script>
	<!-- sticker js -->
	<script src="assets/js/sticker.js"></script>
	<!-- main js -->
	<script src="assets/js/main.js"></script>

</body>
</html>